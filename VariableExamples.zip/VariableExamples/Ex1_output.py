# Chap2 - Variables
# Using print() function to display

# The print function can display the result of evaluated expressions.
print('Hello World')
print("Hello Python World")

# The print function always display in a newline.
print("Hello")
print("Python")
print("World")

print(123)
print (1+2+3)

# A single print function can display several values.
print (3+2, 3-2, 3*2)
