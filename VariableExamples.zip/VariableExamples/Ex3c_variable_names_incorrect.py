# Chap2 - Variables
# Incorrect variable names

p = "Python"       # this is ok, but not descriptive, and therefore not recommended
print(p)

class = "Python"    # a variable name cannot contain keywords
print(class)

my course = "Python"  # a variable name cannot contain spaces
print(my course)

123_course = "Python"  # a variable name cannot start with a number
print(123_course)
