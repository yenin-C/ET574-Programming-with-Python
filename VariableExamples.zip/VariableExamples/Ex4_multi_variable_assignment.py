# Chap2 - Variables
# Multiple variables

# Initialize multiplee variable using different value
x, y, z = "Apple", "Banana", "Cherry"
print(x,y,z)


# Initialize multiple variable using same value
x = y = z = 0
x = y = z = "Orange"
print(x)
print(y)
print(z)

x, y, z = "Apple", 123, 3.14
print(x)
print(y)
print(z)
