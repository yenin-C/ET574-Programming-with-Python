# Chap2 - Variables
# type() function returns the type of the specified object

# using type() to check data types
a = 'Hello, World!'
print(type(a))

a = 17
print(type(a))

a = 3.2
print(type(a))

a = '17'
print(type(a))

a = '3.2'
print(type(a))

a = 2 + 2j
print(type(a))
