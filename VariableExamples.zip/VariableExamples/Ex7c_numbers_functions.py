# Chap2 - Variables
# Using built-in functions with numbers
# S. Trowbridge/J. Sun

# assignment of a single variable a
a = -10
print(a)

# simultaneous assignment of two variables, x and y
x,y = 2,3
print(x)
print(y)

# use  built-in functions
print(abs(a))
print(bool(0))
print(pow(x, y))
print(round(3.1415926535897932, 6))
print(round(3.14, 6))
